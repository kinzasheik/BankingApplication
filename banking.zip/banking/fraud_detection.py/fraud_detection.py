import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

class FraudDetector:
    def __init__(self):
        self.model = IsolationForest(n_estimators=100, contamination=0.02, random_state=42)

    def train_model(self, transaction_data):
        """Train the fraud detection model."""
        features = transaction_data[['amount', 'frequency', 'location_risk']]
        self.model.fit(features)

    def predict(self, transaction):
        """Predict if a transaction is fraudulent (1 = Fraud, -1 = Normal)"""
        return self.model.predict([transaction])[0]

# Sample Usage
if __name__ == "__main__":
    data = pd.DataFrame({'amount': [100, 5000, 200], 'frequency': [2, 1, 10], 'location_risk': [0.1, 0.9, 0.05]})
    detector = FraudDetector()
    detector.train_model(data)
    test_transaction = [1200, 2, 0.8]
    result = detector.predict(test_transaction)
    print("Fraudulent Transaction" if result == 1 else "Normal Transaction")
